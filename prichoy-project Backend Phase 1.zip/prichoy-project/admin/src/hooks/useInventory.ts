import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, getErrorMessage } from '@/lib/api';
import { toast } from 'sonner';
import { Inventory, Warehouse, ApiResponse } from '@/types';

export function useInventory(params: Record<string, string | number | boolean | undefined>) {
  return useQuery({
    queryKey: ['inventory', params],
    queryFn: async () => {
      const { data } = await api.get<ApiResponse<Inventory[]>>('/inventory', { params });
      return data;
    },
  });
}

export function useWarehouses() {
  return useQuery({
    queryKey: ['warehouses'],
    queryFn: async () => {
      const { data } = await api.get<ApiResponse<Warehouse[]>>('/inventory/warehouses');
      return data.data;
    },
  });
}

export function useLowStockAlerts() {
  return useQuery({
    queryKey: ['low-stock-alerts'],
    queryFn: async () => {
      const { data } = await api.get('/inventory/low-stock-alerts');
      return data.data as Inventory[];
    },
  });
}

export function useAdjustStock() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: {
      productId: string; warehouseId: string; type: string;
      quantity: number; reason?: string; note?: string;
    }) => {
      const { data } = await api.post('/inventory/adjust', payload);
      return data.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['inventory'] });
      qc.invalidateQueries({ queryKey: ['products'] });
      toast.success('Stock adjusted');
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useTransferStock() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: {
      productId: string; fromWarehouseId: string; toWarehouseId: string;
      quantity: number; note?: string;
    }) => {
      const { data } = await api.post('/inventory/transfer', payload);
      return data.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['inventory'] });
      toast.success('Stock transferred');
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}
