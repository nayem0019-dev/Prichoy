import rateLimit from 'express-rate-limit';
import { sendError } from '../utils/response';
import { HTTP_STATUS } from '../constants';

export const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Too many requests, please try again later', HTTP_STATUS.TOO_MANY_REQUESTS);
  },
});

// Login: strict, per-IP. Combined with per-account lockout in auth.service.ts
// this provides two independent layers of brute-force protection (an
// attacker rotating IPs still hits the account lockout; an attacker hitting
// one IP hard still hits this limiter regardless of which account they try).
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Too many login attempts, please try again in 15 minutes', HTTP_STATUS.TOO_MANY_REQUESTS);
  },
});

// Refresh-token endpoint is unauthenticated by nature (that's its purpose),
// so it needs its own throttle independent of the general limiter to stop
// it being hammered for token-guessing / DoS purposes.
export const refreshLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Too many refresh attempts, please try again later', HTTP_STATUS.TOO_MANY_REQUESTS);
  },
});

// Sensitive authenticated actions (register new admin, change password).
// Stricter than the general limiter since these are high-value targets for
// an attacker who has already obtained a valid access token.
export const sensitiveActionLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Too many attempts, please try again in 15 minutes', HTTP_STATUS.TOO_MANY_REQUESTS);
  },
});

export const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    sendError(res, 'Upload limit reached, try again later', HTTP_STATUS.TOO_MANY_REQUESTS);
  },
});
