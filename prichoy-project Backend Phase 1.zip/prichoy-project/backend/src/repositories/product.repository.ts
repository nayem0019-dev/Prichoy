import { prisma } from '../config/database';
import { Prisma } from '@prisma/client';
import { ProductFilterQuery } from '../types';
import { getPaginationParams, buildPaginationMeta } from '../utils/pagination';

const PRODUCT_INCLUDE = {
  category:  { select: { id:true, name:true, slug:true } },
  brand:     { select: { id:true, name:true } },
  supplier:  { select: { id:true, name:true } },
  images:    { orderBy: { order: 'asc' as const } },
  variants:  true,
  inventories: {
    include: { warehouse: { select: { id:true, name:true } } },
  },
} satisfies Prisma.ProductInclude;

export class ProductRepository {
  async findAll(filter: ProductFilterQuery) {
    const { skip, take, page, limit } = getPaginationParams(filter);
    const where: Prisma.ProductWhereInput = {};

    if (filter.categoryId)          where.categoryId = filter.categoryId;
    if (filter.brandId)             where.brandId    = filter.brandId;
    if (filter.gender)              where.gender     = filter.gender as Prisma.EnumGenderFilter;
    if (filter.isActive !== undefined) where.isActive = filter.isActive;

    if (filter.search) {
      where.OR = [
        { name:    { contains: filter.search } },
        { sku:     { contains: filter.search } },
        { barcode: { contains: filter.search } },
      ];
    }

    if (filter.lowStock) {
      where.inventories = { some: { quantity: { lte: prisma.inventory.fields.lowStockAlert } } };
    }

    const orderBy: Prisma.ProductOrderByWithRelationInput = {};
    if (filter.sortBy === 'name')      orderBy.name      = filter.sortOrder ?? 'asc';
    else if (filter.sortBy === 'price') orderBy.sellingPrice = filter.sortOrder ?? 'asc';
    else if (filter.sortBy === 'sold')  orderBy.totalSold   = filter.sortOrder ?? 'desc';
    else                                orderBy.createdAt   = 'desc';

    const [products, total] = await Promise.all([
      prisma.product.findMany({ where, include: PRODUCT_INCLUDE, orderBy, skip, take }),
      prisma.product.count({ where }),
    ]);

    return { products, meta: buildPaginationMeta(total, page, limit) };
  }

  async findById(id: string) {
    return prisma.product.findUnique({ where: { id }, include: PRODUCT_INCLUDE });
  }

  async findBySku(sku: string) {
    return prisma.product.findUnique({ where: { sku }, include: PRODUCT_INCLUDE });
  }

  async create(data: Prisma.ProductCreateInput) {
    return prisma.product.create({ data, include: PRODUCT_INCLUDE });
  }

  async update(id: string, data: Prisma.ProductUpdateInput) {
    return prisma.product.update({ where: { id }, data, include: PRODUCT_INCLUDE });
  }

  async delete(id: string) {
    return prisma.product.delete({ where: { id } });
  }

  async getLowStock(threshold = 10) {
    return prisma.product.findMany({
      where: {
        isActive: true,
        inventories: { some: { quantity: { lte: threshold }, } },
      },
      include: {
        ...PRODUCT_INCLUDE,
        inventories: { include: { warehouse: true } },
      },
      take: 50,
    });
  }

  async getTopSelling(limit = 10) {
    return prisma.product.findMany({
      where: { isActive: true },
      orderBy: { totalSold: 'desc' },
      take: limit,
      include: {
        images: { where: { isPrimary: true }, take: 1 },
        category: { select: { name: true } },
      },
    });
  }

  async addImage(productId: string, data: { url: string; alt?: string; isPrimary?: boolean }) {
    if (data.isPrimary) {
      await prisma.productImage.updateMany({
        where: { productId },
        data: { isPrimary: false },
      });
    }
    return prisma.productImage.create({ data: { productId, ...data } });
  }

  async deleteImage(id: string) {
    return prisma.productImage.delete({ where: { id } });
  }
}

export const productRepository = new ProductRepository();
