import { prisma } from '../config/database';
import { OrderStatus, Prisma } from '@prisma/client';
import { OrderFilterQuery } from '../types';
import { getPaginationParams, buildPaginationMeta } from '../utils/pagination';

const ORDER_INCLUDE = {
  customer:  { select: { id:true, name:true, phone:true, email:true } },
  address:   true,
  items: {
    include: {
      product: { select: { id:true, name:true, sku:true } },
      variant: { select: { id:true, name:true, value:true } },
    },
  },
  courier:   { select: { id:true, name:true, website:true } },
  payment:   true,
  history: {
    include: { admin: { select: { id:true, name:true } } },
    orderBy: { createdAt: 'asc' as const },
  },
  refund: true,
  return: true,
} satisfies Prisma.OrderInclude;

export class OrderRepository {
  async findAll(filter: OrderFilterQuery) {
    const { skip, take, page, limit } = getPaginationParams(filter);

    const where: Prisma.OrderWhereInput = {};

    if (filter.status)        where.status        = filter.status as OrderStatus;
    if (filter.paymentStatus) where.paymentStatus = filter.paymentStatus as Prisma.EnumPaymentStatusFilter;
    if (filter.courierId)     where.courierId     = filter.courierId;
    if (filter.customerId)    where.customerId    = filter.customerId;

    if (filter.startDate || filter.endDate) {
      where.createdAt = {};
      if (filter.startDate) where.createdAt.gte = new Date(filter.startDate);
      if (filter.endDate)   where.createdAt.lte = new Date(filter.endDate + 'T23:59:59');
    }

    if (filter.search) {
      where.OR = [
        { orderNo:      { contains: filter.search } },
        { invoiceNo:    { contains: filter.search } },
        { trackingNumber: { contains: filter.search } },
        { shippingPhone: { contains: filter.search } },
        { customer: { name:  { contains: filter.search } } },
        { customer: { phone: { contains: filter.search } } },
        { customer: { email: { contains: filter.search } } },
      ];
    }

    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: ORDER_INCLUDE,
        orderBy: { createdAt: 'desc' },
        skip,
        take,
      }),
      prisma.order.count({ where }),
    ]);

    return { orders, meta: buildPaginationMeta(total, page, limit) };
  }

  async findById(id: string) {
    return prisma.order.findUnique({ where: { id }, include: ORDER_INCLUDE });
  }

  async findByOrderNo(orderNo: string) {
    return prisma.order.findUnique({ where: { orderNo }, include: ORDER_INCLUDE });
  }

  async create(data: Prisma.OrderCreateInput) {
    return prisma.order.create({ data, include: ORDER_INCLUDE });
  }

  async update(id: string, data: Prisma.OrderUpdateInput) {
    return prisma.order.update({ where: { id }, data, include: ORDER_INCLUDE });
  }

  async addHistory(data: {
    orderId: string;
    status: OrderStatus;
    adminId?: string;
    note?: string;
    ip?: string;
  }) {
    return prisma.orderHistory.create({ data });
  }

  async getDashboardStats() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const yearStart  = new Date(today.getFullYear(), 0, 1);

    const [
      totalOrders, todayOrders, pendingOrders,
      confirmedOrders, packedOrders, dispatchedOrders,
      deliveredOrders, cancelledOrders, returnedOrders,
      refundedOrders,
    ] = await Promise.all([
      prisma.order.count(),
      prisma.order.count({ where: { createdAt: { gte: today, lte: todayEnd } } }),
      prisma.order.count({ where: { status: 'PENDING' } }),
      prisma.order.count({ where: { status: 'CONFIRMED' } }),
      prisma.order.count({ where: { status: 'PACKED' } }),
      prisma.order.count({ where: { status: 'DISPATCHED' } }),
      prisma.order.count({ where: { status: 'DELIVERED' } }),
      prisma.order.count({ where: { status: 'CANCELLED' } }),
      prisma.order.count({ where: { status: 'RETURNED' } }),
      prisma.order.count({ where: { status: 'REFUNDED' } }),
    ]);

    const [todayRevenue, monthRevenue, yearRevenue, totalRevenue] = await Promise.all([
      prisma.order.aggregate({
        where: { status: 'DELIVERED', createdAt: { gte: today, lte: todayEnd } },
        _sum: { grandTotal: true },
      }),
      prisma.order.aggregate({
        where: { status: 'DELIVERED', createdAt: { gte: monthStart } },
        _sum: { grandTotal: true },
      }),
      prisma.order.aggregate({
        where: { status: 'DELIVERED', createdAt: { gte: yearStart } },
        _sum: { grandTotal: true },
      }),
      prisma.order.aggregate({
        where: { status: 'DELIVERED' },
        _sum: { grandTotal: true },
      }),
    ]);

    return {
      orders: {
        total: totalOrders, today: todayOrders,
        pending: pendingOrders, confirmed: confirmedOrders,
        packed: packedOrders, dispatched: dispatchedOrders,
        delivered: deliveredOrders, cancelled: cancelledOrders,
        returned: returnedOrders, refunded: refundedOrders,
      },
      revenue: {
        today:  Number(todayRevenue._sum.grandTotal  || 0),
        month:  Number(monthRevenue._sum.grandTotal  || 0),
        year:   Number(yearRevenue._sum.grandTotal   || 0),
        total:  Number(totalRevenue._sum.grandTotal  || 0),
      },
    };
  }

  async getRecentOrders(limit = 10) {
    return prisma.order.findMany({
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        customer: { select: { id:true, name:true, phone:true } },
        courier:  { select: { id:true, name:true } },
      },
    });
  }

  async getSalesChart(days = 30) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const orders = await prisma.order.findMany({
      where: {
        status: 'DELIVERED',
        createdAt: { gte: startDate },
      },
      select: { grandTotal: true, createdAt: true },
      orderBy: { createdAt: 'asc' },
    });

    // Group by date
    const byDate: Record<string, number> = {};
    orders.forEach((o) => {
      const key = o.createdAt.toISOString().split('T')[0];
      byDate[key] = (byDate[key] || 0) + Number(o.grandTotal);
    });

    return Object.entries(byDate).map(([date, total]) => ({ date, total }));
  }

  async bulkUpdateStatus(orderIds: string[], status: OrderStatus, adminId?: string) {
    const result = await prisma.$transaction(async (tx) => {
      await tx.order.updateMany({
        where: { id: { in: orderIds } },
        data: { status },
      });
      await tx.orderHistory.createMany({
        data: orderIds.map((orderId) => ({
          orderId, status, adminId,
          note: `Bulk status update to ${status}`,
        })),
      });
      return orderIds.length;
    });
    return result;
  }
}

export const orderRepository = new OrderRepository();
