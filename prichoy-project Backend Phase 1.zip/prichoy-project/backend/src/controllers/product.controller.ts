import { Response } from 'express';
import asyncHandler from 'express-async-handler';
import { AuthRequest } from '../types';
import { productService } from '../services/product.service';
import { sendSuccess, sendCreated, sendPaginated } from '../utils/response';

// Products
export const getProducts = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { products, meta } = await productService.getAll(req.query as never);
  sendPaginated(res, products, meta);
});

export const getProduct = asyncHandler(async (req: AuthRequest, res: Response) => {
  const product = await productService.getById(req.params.id);
  sendSuccess(res, product);
});

export const createProduct = asyncHandler(async (req: AuthRequest, res: Response) => {
  const product = await productService.create(req.body);
  sendCreated(res, product, 'Product created');
});

export const updateProduct = asyncHandler(async (req: AuthRequest, res: Response) => {
  const product = await productService.update(req.params.id, req.body);
  sendSuccess(res, product, 'Product updated');
});

export const deleteProduct = asyncHandler(async (req: AuthRequest, res: Response) => {
  await productService.delete(req.params.id);
  sendSuccess(res, null, 'Product deleted');
});

export const getLowStockProducts = asyncHandler(async (req: AuthRequest, res: Response) => {
  const products = await productService.getLowStock(Number(req.query.threshold));
  sendSuccess(res, products);
});

export const getTopSellingProducts = asyncHandler(async (req: AuthRequest, res: Response) => {
  const products = await productService.getTopSelling(Number(req.query.limit) || 10);
  sendSuccess(res, products);
});

export const addProductImage = asyncHandler(async (req: AuthRequest, res: Response) => {
  const image = await productService.addImage(req.params.id, req.body);
  sendCreated(res, image, 'Image added');
});

export const deleteProductImage = asyncHandler(async (req: AuthRequest, res: Response) => {
  await productService.deleteImage(req.params.productId, req.params.imageId);
  sendSuccess(res, null, 'Image deleted');
});

// Categories
export const getCategories = asyncHandler(async (_req: AuthRequest, res: Response) => {
  const categories = await productService.getCategories();
  sendSuccess(res, categories);
});

export const createCategory = asyncHandler(async (req: AuthRequest, res: Response) => {
  const category = await productService.createCategory(req.body);
  sendCreated(res, category, 'Category created');
});

export const updateCategory = asyncHandler(async (req: AuthRequest, res: Response) => {
  const category = await productService.updateCategory(req.params.id, req.body);
  sendSuccess(res, category, 'Category updated');
});

export const deleteCategory = asyncHandler(async (req: AuthRequest, res: Response) => {
  await productService.deleteCategory(req.params.id);
  sendSuccess(res, null, 'Category deleted');
});

// Brands
export const getBrands = asyncHandler(async (_req: AuthRequest, res: Response) => {
  const brands = await productService.getBrands();
  sendSuccess(res, brands);
});

export const createBrand = asyncHandler(async (req: AuthRequest, res: Response) => {
  const brand = await productService.createBrand(req.body);
  sendCreated(res, brand, 'Brand created');
});

export const updateBrand = asyncHandler(async (req: AuthRequest, res: Response) => {
  const brand = await productService.updateBrand(req.params.id, req.body);
  sendSuccess(res, brand, 'Brand updated');
});

export const deleteBrand = asyncHandler(async (req: AuthRequest, res: Response) => {
  await productService.deleteBrand(req.params.id);
  sendSuccess(res, null, 'Brand deleted');
});
