import { Response } from 'express';
import asyncHandler from 'express-async-handler';
import { AuthRequest } from '../types';
import { orderService } from '../services/order.service';
import { sendSuccess, sendCreated, sendPaginated } from '../utils/response';
import { OrderStatus } from '@prisma/client';

export const getOrders = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { orders, meta } = await orderService.getAll(req.query as never);
  sendPaginated(res, orders, meta);
});

export const getOrder = asyncHandler(async (req: AuthRequest, res: Response) => {
  const order = await orderService.getById(req.params.id);
  sendSuccess(res, order);
});

export const createOrder = asyncHandler(async (req: AuthRequest, res: Response) => {
  const order = await orderService.create(
    { ...req.body, sourceIp: req.ip },
    req.user?.userId
  );
  sendCreated(res, order, 'Order created successfully');
});

export const updateOrderStatus = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { status, note, courierId, trackingNumber, cancelReason } = req.body;
  const order = await orderService.updateStatus(
    req.params.id,
    status as OrderStatus,
    req.user!.userId,
    { note, courierId, trackingNumber, cancelReason, ip: req.ip }
  );
  sendSuccess(res, order, `Order status updated to ${status}`);
});

export const addNote = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { note, isInternal } = req.body;
  await orderService.addNote(req.params.id, note, req.user!.userId, isInternal);
  sendSuccess(res, null, 'Note added');
});

export const assignCourier = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { courierId, trackingNumber } = req.body;
  const order = await orderService.assignCourier(
    req.params.id, courierId, trackingNumber, req.user!.userId
  );
  sendSuccess(res, order, 'Courier assigned');
});

export const processReturn = asyncHandler(async (req: AuthRequest, res: Response) => {
  await orderService.processReturn(req.params.id, {
    ...req.body,
    adminId: req.user!.userId,
  });
  sendSuccess(res, null, 'Return processed');
});

export const processRefund = asyncHandler(async (req: AuthRequest, res: Response) => {
  await orderService.processRefund(req.params.id, {
    ...req.body,
    adminId: req.user!.userId,
  });
  sendSuccess(res, null, 'Refund initiated');
});

export const bulkAction = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { orderIds, action, ...payload } = req.body;
  const count = await orderService.bulkAction(orderIds, action, req.user!.userId, payload);
  sendSuccess(res, { affected: count }, `Bulk ${action} completed`);
});

export const getDashboard = asyncHandler(async (_req: AuthRequest, res: Response) => {
  const stats = await orderService.getDashboardStats();
  sendSuccess(res, stats);
});

export const getRecentOrders = asyncHandler(async (req: AuthRequest, res: Response) => {
  const orders = await orderService.getRecentOrders(Number(req.query.limit) || 10);
  sendSuccess(res, orders);
});

export const getSalesChart = asyncHandler(async (req: AuthRequest, res: Response) => {
  const data = await orderService.getSalesChart(Number(req.query.days) || 30);
  sendSuccess(res, data);
});
