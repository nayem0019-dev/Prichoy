import { Response } from 'express';
import asyncHandler from 'express-async-handler';
import { AuthRequest } from '../types';
import { customerService } from '../services/customer.service';
import { sendSuccess, sendPaginated } from '../utils/response';

export const getCustomers = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { customers, meta } = await customerService.getAll(req.query as never);
  sendPaginated(res, customers, meta);
});

export const getCustomer = asyncHandler(async (req: AuthRequest, res: Response) => {
  const customer = await customerService.getById(req.params.id);
  sendSuccess(res, customer);
});

export const updateCustomer = asyncHandler(async (req: AuthRequest, res: Response) => {
  const customer = await customerService.update(req.params.id, req.body);
  sendSuccess(res, customer, 'Customer updated');
});

export const addNote = asyncHandler(async (req: AuthRequest, res: Response) => {
  await customerService.addNote(req.params.id, req.body.note);
  sendSuccess(res, null, 'Note saved');
});

export const blockCustomer = asyncHandler(async (req: AuthRequest, res: Response) => {
  const customer = await customerService.block(req.params.id, req.body.reason);
  sendSuccess(res, customer, 'Customer blocked');
});

export const unblockCustomer = asyncHandler(async (req: AuthRequest, res: Response) => {
  const customer = await customerService.unblock(req.params.id);
  sendSuccess(res, customer, 'Customer unblocked');
});

export const getTopCustomers = asyncHandler(async (req: AuthRequest, res: Response) => {
  const customers = await customerService.getTopCustomers(Number(req.query.limit) || 10);
  sendSuccess(res, customers);
});

export const getCustomerStats = asyncHandler(async (_req: AuthRequest, res: Response) => {
  const stats = await customerService.getStats();
  sendSuccess(res, stats);
});
