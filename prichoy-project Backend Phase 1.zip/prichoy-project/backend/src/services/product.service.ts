import { Prisma } from '@prisma/client';
import { prisma } from '../config/database';
import { productRepository } from '../repositories/product.repository';
import { AppError } from '../middlewares/error.middleware';
import { HTTP_STATUS } from '../constants';
import { ProductFilterQuery } from '../types';

export class ProductService {
  async getAll(filter: ProductFilterQuery) {
    return productRepository.findAll(filter);
  }

  async getById(id: string) {
    const product = await productRepository.findById(id);
    if (!product) throw new AppError('Product not found', HTTP_STATUS.NOT_FOUND);
    return product;
  }

  async create(data: {
    name: string; slug: string; description?: string; sku: string;
    barcode?: string; gender?: string; categoryId: string; brandId?: string;
    supplierId?: string; costPrice: number; sellingPrice: number; salePrice?: number;
    weight?: number; isActive?: boolean; isFeatured?: boolean;
    warehouseId: string; initialStock?: number;
  }) {
    const existing = await productRepository.findBySku(data.sku);
    if (existing) throw new AppError('SKU already exists', HTTP_STATUS.CONFLICT);

    return prisma.$transaction(async (tx) => {
      const margin = data.sellingPrice > 0
        ? ((data.sellingPrice - data.costPrice) / data.sellingPrice) * 100
        : 0;

      const product = await tx.product.create({
        data: {
          name: data.name, slug: data.slug,
          description: data.description, sku: data.sku,
          barcode: data.barcode,
          gender: data.gender as Prisma.EnumGenderFilter | undefined,
          categoryId: data.categoryId, brandId: data.brandId,
          supplierId: data.supplierId,
          costPrice: data.costPrice, sellingPrice: data.sellingPrice,
          salePrice: data.salePrice, profitMargin: Math.round(margin * 100) / 100,
          weight: data.weight, isActive: data.isActive ?? true,
          isFeatured: data.isFeatured ?? false,
        },
      });

      // Create default inventory in the specified warehouse
      await tx.inventory.create({
        data: {
          productId: product.id,
          warehouseId: data.warehouseId,
          quantity: data.initialStock ?? 0,
        },
      });

      return product;
    });
  }

  async update(id: string, data: Partial<{
    name: string; slug: string; description: string; barcode: string;
    gender: string; categoryId: string; brandId: string; supplierId: string;
    costPrice: number; sellingPrice: number; salePrice: number;
    weight: number; isActive: boolean; isFeatured: boolean;
  }>) {
    await this.getById(id);

    const updateData: Prisma.ProductUpdateInput = { ...data };
    if (data.costPrice !== undefined && data.sellingPrice !== undefined) {
      updateData.profitMargin = Math.round(
        ((data.sellingPrice - data.costPrice) / data.sellingPrice) * 100 * 100
      ) / 100;
    }
    return productRepository.update(id, updateData);
  }

  async delete(id: string) {
    await this.getById(id);
    const orderCount = await prisma.orderItem.count({ where: { productId: id } });
    if (orderCount > 0) {
      // Soft delete instead
      return productRepository.update(id, { isActive: false });
    }
    return productRepository.delete(id);
  }

  async getLowStock(threshold?: number) {
    return productRepository.getLowStock(threshold);
  }

  async getTopSelling(limit?: number) {
    return productRepository.getTopSelling(limit);
  }

  async addImage(productId: string, data: { url: string; alt?: string; isPrimary?: boolean }) {
    await this.getById(productId);
    return productRepository.addImage(productId, data);
  }

  async deleteImage(productId: string, imageId: string) {
    await this.getById(productId);
    return productRepository.deleteImage(imageId);
  }

  // Categories
  async getCategories() {
    return prisma.category.findMany({
      include: { _count: { select: { products: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async createCategory(data: { name: string; slug: string; gender?: string; description?: string }) {
    return prisma.category.create({ data: data as Prisma.CategoryCreateInput });
  }

  async updateCategory(id: string, data: Partial<{ name: string; slug: string; gender: string; description: string; isActive: boolean }>) {
    return prisma.category.update({ where: { id }, data: data as Prisma.CategoryUpdateInput });
  }

  async deleteCategory(id: string) {
    const productCount = await prisma.product.count({ where: { categoryId: id } });
    if (productCount > 0) throw new AppError(`Category has ${productCount} products. Reassign them first.`, HTTP_STATUS.CONFLICT);
    return prisma.category.delete({ where: { id } });
  }

  // Brands
  async getBrands() {
    return prisma.brand.findMany({
      include: { _count: { select: { products: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async createBrand(data: { name: string; slug: string; description?: string }) {
    return prisma.brand.create({ data });
  }

  async updateBrand(id: string, data: Partial<{ name: string; slug: string; description: string; isActive: boolean }>) {
    return prisma.brand.update({ where: { id }, data });
  }

  async deleteBrand(id: string) {
    return prisma.brand.delete({ where: { id } });
  }
}

export const productService = new ProductService();
