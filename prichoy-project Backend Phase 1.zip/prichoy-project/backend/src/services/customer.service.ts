import { Prisma } from '@prisma/client';
import { prisma } from '../config/database';
import { AppError } from '../middlewares/error.middleware';
import { HTTP_STATUS } from '../constants';
import { getPaginationParams, buildPaginationMeta } from '../utils/pagination';
import { PaginationQuery } from '../types';

export class CustomerService {
  async getAll(filter: PaginationQuery & { tag?: string; isBlocked?: boolean }) {
    const { skip, take, page, limit } = getPaginationParams(filter);
    const where: Prisma.CustomerWhereInput = {};

    if (filter.tag)                    where.tag       = filter.tag as Prisma.EnumCustomerTagFilter;
    if (filter.isBlocked !== undefined) where.isBlocked = filter.isBlocked;

    if (filter.search) {
      where.OR = [
        { name:  { contains: filter.search } },
        { phone: { contains: filter.search } },
        { email: { contains: filter.search } },
      ];
    }

    const [customers, total] = await Promise.all([
      prisma.customer.findMany({
        where,
        include: { _count: { select: { orders: true } }, addresses: true },
        orderBy: { createdAt: 'desc' },
        skip, take,
      }),
      prisma.customer.count({ where }),
    ]);

    return { customers, meta: buildPaginationMeta(total, page, limit) };
  }

  async getById(id: string) {
    const customer = await prisma.customer.findUnique({
      where: { id },
      include: {
        addresses: true,
        orders: {
          orderBy: { createdAt: 'desc' },
          take: 10,
          include: { items: { take: 3 } },
        },
      },
    });
    if (!customer) throw new AppError('Customer not found', HTTP_STATUS.NOT_FOUND);
    return customer;
  }

  async findOrCreate(data: {
    name: string; phone: string; email?: string;
    address?: string; thana?: string; district?: string;
  }) {
    const existing = await prisma.customer.findUnique({ where: { phone: data.phone } });
    if (existing) return existing;

    return prisma.customer.create({
      data: {
        name: data.name, phone: data.phone, email: data.email,
        addresses: data.address ? {
          create: {
            line1: data.address,
            thana: data.thana ?? '',
            district: data.district ?? '',
            isDefault: true,
          },
        } : undefined,
      },
      include: { addresses: true },
    });
  }

  async update(id: string, data: Partial<{
    name: string; email: string; notes: string;
    tag: string; isBlocked: boolean; blockReason: string;
  }>) {
    await this.getById(id);
    return prisma.customer.update({
      where: { id },
      data: data as Prisma.CustomerUpdateInput,
    });
  }

  async addNote(id: string, note: string) {
    await this.getById(id);
    return prisma.customer.update({ where: { id }, data: { notes: note } });
  }

  async block(id: string, reason: string) {
    return prisma.customer.update({
      where: { id },
      data: { isBlocked: true, blockReason: reason, tag: 'BLOCKED' },
    });
  }

  async unblock(id: string) {
    return prisma.customer.update({
      where: { id },
      data: { isBlocked: false, blockReason: null, tag: 'REGULAR' },
    });
  }

  async getTopCustomers(limit = 10) {
    return prisma.customer.findMany({
      where: { isBlocked: false },
      orderBy: { totalSpent: 'desc' },
      take: limit,
      select: {
        id: true, name: true, phone: true, email: true,
        totalOrders: true, totalSpent: true, tag: true, lastOrderAt: true,
      },
    });
  }

  async getStats() {
    const [total, vip, blocked, newCustomers] = await Promise.all([
      prisma.customer.count(),
      prisma.customer.count({ where: { tag: 'VIP' } }),
      prisma.customer.count({ where: { isBlocked: true } }),
      prisma.customer.count({
        where: { createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } },
      }),
    ]);
    return { total, vip, blocked, newThisMonth: newCustomers };
  }
}

export const customerService = new CustomerService();
