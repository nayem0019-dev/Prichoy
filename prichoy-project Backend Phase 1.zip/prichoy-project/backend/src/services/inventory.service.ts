import { StockMovementType, Prisma } from '@prisma/client';
import { prisma } from '../config/database';
import { AppError } from '../middlewares/error.middleware';
import { HTTP_STATUS } from '../constants';
import { getPaginationParams, buildPaginationMeta } from '../utils/pagination';
import { PaginationQuery } from '../types';

export class InventoryService {
  async getAll(filter: PaginationQuery & { warehouseId?: string; lowStock?: boolean }) {
    const { skip, take, page, limit } = getPaginationParams(filter);
    const where: Prisma.InventoryWhereInput = {};

    if (filter.warehouseId) where.warehouseId = filter.warehouseId;
    if (filter.lowStock)    where.quantity    = { lte: prisma.inventory.fields.lowStockAlert };

    if (filter.search) {
      where.product = {
        OR: [
          { name:    { contains: filter.search } },
          { sku:     { contains: filter.search } },
          { barcode: { contains: filter.search } },
        ],
      };
    }

    const [inventories, total] = await Promise.all([
      prisma.inventory.findMany({
        where,
        include: {
          product: {
            include: {
              images:   { where: { isPrimary: true }, take: 1 },
              category: { select: { name: true } },
            },
          },
          warehouse: { select: { id: true, name: true } },
        },
        orderBy: { updatedAt: 'desc' },
        skip, take,
      }),
      prisma.inventory.count({ where }),
    ]);

    return { inventories, meta: buildPaginationMeta(total, page, limit) };
  }

  async getMovements(inventoryId: string, query: PaginationQuery) {
    const { skip, take, page, limit } = getPaginationParams(query);

    const [movements, total] = await Promise.all([
      prisma.stockMovement.findMany({
        where: { inventoryId },
        orderBy: { createdAt: 'desc' },
        skip, take,
      }),
      prisma.stockMovement.count({ where: { inventoryId } }),
    ]);

    return { movements, meta: buildPaginationMeta(total, page, limit) };
  }

  async adjustStock(data: {
    productId: string;
    warehouseId: string;
    type: StockMovementType;
    quantity: number;
    reason?: string;
    reference?: string;
    adminId?: string;
    note?: string;
  }) {
    const inventory = await prisma.inventory.findUnique({
      where: { productId_warehouseId: { productId: data.productId, warehouseId: data.warehouseId } },
    });

    if (!inventory) throw new AppError('Inventory record not found', HTTP_STATUS.NOT_FOUND);

    const isDeduction = ['STOCK_OUT', 'RESERVE', 'TRANSFER'].includes(data.type);
    const available = inventory.quantity - inventory.reserved;

    if (isDeduction && available < data.quantity) {
      throw new AppError(
        `Insufficient stock. Available: ${available}, Requested: ${data.quantity}`,
        HTTP_STATUS.BAD_REQUEST
      );
    }

    const previousStock = inventory.quantity;
    const newStock      = isDeduction ? previousStock - data.quantity : previousStock + data.quantity;

    return prisma.$transaction(async (tx) => {
      const updated = await tx.inventory.update({
        where: { id: inventory.id },
        data: {
          quantity: newStock,
          reserved: data.type === 'RESERVE'
            ? { increment: data.quantity }
            : data.type === 'UNRESERVE'
              ? { decrement: data.quantity }
              : undefined,
        },
      });

      await tx.stockMovement.create({
        data: {
          inventoryId: inventory.id,
          type:        data.type,
          quantity:    data.quantity,
          previousStock,
          newStock,
          reason:      data.reason,
          reference:   data.reference,
          adminId:     data.adminId,
          note:        data.note,
        },
      });

      // Notify if low stock
      if (newStock <= inventory.lowStockAlert && newStock > 0) {
        await tx.notification.create({
          data: {
            type:  'LOW_STOCK',
            title: 'Low Stock Alert',
            body:  `Stock for product is low (${newStock} remaining)`,
          },
        });
      }

      if (newStock === 0) {
        await tx.notification.create({
          data: {
            type:  'OUT_OF_STOCK',
            title: 'Out of Stock',
            body:  `A product is now out of stock`,
          },
        });
      }

      return updated;
    });
  }

  async transferStock(data: {
    productId: string;
    fromWarehouseId: string;
    toWarehouseId: string;
    quantity: number;
    adminId: string;
    note?: string;
  }) {
    // Deduct from source
    await this.adjustStock({
      productId:   data.productId,
      warehouseId: data.fromWarehouseId,
      type:        'STOCK_OUT',
      quantity:    data.quantity,
      reason:      'Transfer out',
      adminId:     data.adminId,
      note:        data.note,
    });

    // Add to destination
    let destInventory = await prisma.inventory.findUnique({
      where: { productId_warehouseId: { productId: data.productId, warehouseId: data.toWarehouseId } },
    });

    if (!destInventory) {
      destInventory = await prisma.inventory.create({
        data: { productId: data.productId, warehouseId: data.toWarehouseId, quantity: 0 },
      });
    }

    return this.adjustStock({
      productId:   data.productId,
      warehouseId: data.toWarehouseId,
      type:        'TRANSFER',
      quantity:    data.quantity,
      reason:      'Transfer in',
      adminId:     data.adminId,
      note:        data.note,
    });
  }

  async getWarehouses() {
    return prisma.warehouse.findMany({
      include: { _count: { select: { inventories: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async createWarehouse(data: { name: string; location?: string; isDefault?: boolean }) {
    return prisma.warehouse.create({ data });
  }

  async getLowStockAlerts() {
    return prisma.inventory.findMany({
      where: {
        product: { isActive: true },
        OR: [
          { quantity: { lte: 10 } },
          { quantity: 0 },
        ],
      },
      include: {
        product: { include: { images: { where: { isPrimary: true }, take: 1 } } },
        warehouse: { select: { name: true } },
      },
      orderBy: { quantity: 'asc' },
      take: 50,
    });
  }
}

export const inventoryService = new InventoryService();
