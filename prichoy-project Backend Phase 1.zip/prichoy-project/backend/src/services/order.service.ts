import { OrderStatus, Prisma } from '@prisma/client';
import { prisma } from '../config/database';
import { orderRepository } from '../repositories/order.repository';
import { AppError } from '../middlewares/error.middleware';
import { HTTP_STATUS, ORDER_STATUS_FLOW, DELIVERY_CHARGES, DHAKA_DISTRICTS } from '../constants';
import { generateOrderNumber, generateInvoiceNumber } from '../utils/orderNumber';
import { OrderFilterQuery } from '../types';

interface CreateOrderData {
  customerId:      string;
  shippingName:    string;
  shippingPhone:   string;
  shippingAddress: string;
  shippingThana:   string;
  shippingDistrict:string;
  addressId?:      string;
  items: Array<{
    productId:   string;
    variantId?:  string;
    productName: string;
    variantInfo?: string;
    sku?:        string;
    image?:      string;
    quantity:    number;
    unitPrice:   number;
    discount?:   number;
  }>;
  paymentMethod?:  string;
  couponCode?:     string;
  discountAmount?: number;
  notes?:          string;
  sourceIp?:       string;
}

export class OrderService {
  async getAll(filter: OrderFilterQuery) {
    return orderRepository.findAll(filter);
  }

  async getById(id: string) {
    const order = await orderRepository.findById(id);
    if (!order) throw new AppError('Order not found', HTTP_STATUS.NOT_FOUND);
    return order;
  }

  async create(data: CreateOrderData, adminId?: string) {
    const [orderNo, invoiceNo] = await Promise.all([
      generateOrderNumber(),
      generateInvoiceNumber(),
    ]);

    // Calculate totals
    const subtotal = data.items.reduce(
      (sum, item) => sum + (item.unitPrice * item.quantity) - (item.discount ?? 0),
      0
    );
    const discountAmount = data.discountAmount ?? 0;
    const isDhaka = DHAKA_DISTRICTS.some((d) =>
      data.shippingDistrict.toLowerCase().includes(d.toLowerCase())
    );
    const shippingCharge = isDhaka ? DELIVERY_CHARGES.DHAKA_CITY : DELIVERY_CHARGES.OUTSIDE_DHAKA;
    const grandTotal = subtotal - discountAmount + shippingCharge;

    const order = await prisma.$transaction(async (tx) => {
      const created = await tx.order.create({
        data: {
          orderNo,
          invoiceNo,
          customerId:       data.customerId,
          addressId:        data.addressId,
          shippingName:     data.shippingName,
          shippingPhone:    data.shippingPhone,
          shippingAddress:  data.shippingAddress,
          shippingThana:    data.shippingThana,
          shippingDistrict: data.shippingDistrict,
          paymentMethod:    (data.paymentMethod as Prisma.EnumPaymentMethodFieldUpdateOperationsInput) ?? 'COD',
          couponCode:       data.couponCode,
          discountAmount,
          shippingCharge,
          subtotal,
          grandTotal,
          notes:            data.notes,
          sourceIp:         data.sourceIp,
          items: {
            create: data.items.map((item) => ({
              productId:   item.productId,
              variantId:   item.variantId,
              productName: item.productName,
              variantInfo: item.variantInfo,
              sku:         item.sku,
              image:       item.image,
              quantity:    item.quantity,
              unitPrice:   item.unitPrice,
              discount:    item.discount ?? 0,
              totalPrice:  (item.unitPrice * item.quantity) - (item.discount ?? 0),
            })),
          },
          payment: {
            create: {
              method: (data.paymentMethod as Prisma.EnumPaymentMethodFieldUpdateOperationsInput) ?? 'COD',
              amount: grandTotal,
              status: 'UNPAID',
            },
          },
          history: {
            create: {
              status: 'PENDING',
              adminId,
              note: 'Order placed',
            },
          },
        },
        include: {
          items: true,
          customer: { select: { id:true, name:true, phone:true, email:true } },
          payment: true,
          history: true,
        },
      });

      // Update customer stats
      await tx.customer.update({
        where: { id: data.customerId },
        data: {
          totalOrders: { increment: 1 },
          totalSpent:  { increment: grandTotal },
          lastOrderAt: new Date(),
        },
      });

      // Re-calculate average order
      const customer = await tx.customer.findUnique({ where: { id: data.customerId } });
      if (customer) {
        await tx.customer.update({
          where: { id: data.customerId },
          data: {
            averageOrder: Number(customer.totalSpent) / customer.totalOrders,
          },
        });
      }

      return created;
    });

    return order;
  }

  async updateStatus(
    orderId: string,
    newStatus: OrderStatus,
    adminId: string,
    options?: { note?: string; ip?: string; courierId?: string; trackingNumber?: string; cancelReason?: string }
  ) {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new AppError('Order not found', HTTP_STATUS.NOT_FOUND);

    const allowed = ORDER_STATUS_FLOW[order.status];
    if (!allowed?.includes(newStatus)) {
      throw new AppError(
        `Cannot transition from ${order.status} to ${newStatus}`,
        HTTP_STATUS.BAD_REQUEST
      );
    }

    const updateData: Prisma.OrderUpdateInput = { status: newStatus };

    if (newStatus === 'DISPATCHED') {
      if (!options?.courierId)     throw new AppError('Courier required for dispatch', HTTP_STATUS.BAD_REQUEST);
      if (!options?.trackingNumber) throw new AppError('Tracking number required', HTTP_STATUS.BAD_REQUEST);
      updateData.courierId      = options.courierId;
      updateData.trackingNumber = options.trackingNumber;
      updateData.dispatchedAt   = new Date();
    }

    if (newStatus === 'DELIVERED') {
      updateData.deliveredAt    = new Date();
      updateData.paymentStatus  = 'PAID';
      // Mark payment as paid
      await prisma.payment.updateMany({
        where: { orderId },
        data:  { status: 'PAID', paidAt: new Date(), paidAmount: order.grandTotal },
      });
    }

    if (newStatus === 'CANCELLED') {
      if (!options?.cancelReason) throw new AppError('Cancellation reason required', HTTP_STATUS.BAD_REQUEST);
      updateData.cancelledAt  = new Date();
      updateData.cancelledBy  = adminId;
      updateData.cancelReason = options.cancelReason;
      // Restore reserved stock
      await this.restoreStock(orderId, adminId);
    }

    if (newStatus === 'CONFIRMED') {
      // Reserve stock
      await this.reserveStock(orderId);
    }

    const updated = await orderRepository.update(orderId, updateData);
    await orderRepository.addHistory({
      orderId,
      status: newStatus,
      adminId,
      note: options?.note,
      ip:   options?.ip,
    });

    return updated;
  }

  async addNote(orderId: string, note: string, adminId: string, isInternal = false) {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new AppError('Order not found', HTTP_STATUS.NOT_FOUND);

    await orderRepository.update(orderId, {
      [isInternal ? 'adminNotes' : 'notes']: note,
    });

    await prisma.activityLog.create({
      data: {
        adminId,
        action:   'ADD_NOTE',
        entity:   'orders',
        entityId: orderId,
        newValue: JSON.stringify({ note, isInternal }),
      },
    });
  }

  async assignCourier(
    orderId: string,
    courierId: string,
    trackingNumber: string,
    adminId: string
  ) {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new AppError('Order not found', HTTP_STATUS.NOT_FOUND);

    return orderRepository.update(orderId, { courierId, trackingNumber });
  }

  async processReturn(orderId: string, data: {
    reason: string;
    condition?: string;
    images?: string[];
    restockItems?: boolean;
    adminId: string;
  }) {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new AppError('Order not found', HTTP_STATUS.NOT_FOUND);

    await prisma.$transaction(async (tx) => {
      await tx.return.create({
        data: {
          orderId,
          reason:       data.reason,
          condition:    data.condition,
          images:       data.images ? JSON.stringify(data.images) : undefined,
          restockItems: data.restockItems ?? true,
        },
      });
      await tx.order.update({ where: { id: orderId }, data: { status: 'RETURNED' } });
      await tx.orderHistory.create({
        data: {
          orderId,
          status:  'RETURNED',
          adminId: data.adminId,
          note:    data.reason,
        },
      });

      if (data.restockItems) {
        await this.restoreStock(orderId, data.adminId, tx);
      }
    });
  }

  async processRefund(orderId: string, data: {
    amount: number;
    method: string;
    reason: string;
    adminId: string;
  }) {
    const order = await orderRepository.findById(orderId);
    if (!order) throw new AppError('Order not found', HTTP_STATUS.NOT_FOUND);

    await prisma.$transaction(async (tx) => {
      await tx.refund.create({
        data: {
          orderId,
          amount:  data.amount,
          method:  data.method as Prisma.EnumPaymentMethodFieldUpdateOperationsInput,
          reason:  data.reason,
          status:  'PENDING',
        },
      });
      await tx.order.update({
        where: { id: orderId },
        data:  { status: 'REFUNDED', paymentStatus: 'REFUNDED' },
      });
      await tx.orderHistory.create({
        data: {
          orderId,
          status:  'REFUNDED',
          adminId: data.adminId,
          note:    `Refund of ৳${data.amount} via ${data.method}`,
        },
      });
    });
  }

  async getDashboardStats() {
    return orderRepository.getDashboardStats();
  }

  async getRecentOrders(limit = 10) {
    return orderRepository.getRecentOrders(limit);
  }

  async getSalesChart(days = 30) {
    return orderRepository.getSalesChart(days);
  }

  async bulkAction(orderIds: string[], action: string, adminId: string, payload?: Record<string, unknown>) {
    switch (action) {
      case 'CONFIRM':
        return orderRepository.bulkUpdateStatus(orderIds, 'CONFIRMED', adminId);
      case 'CANCEL': {
        const reason = (payload?.reason as string) ?? 'Bulk cancelled';
        for (const id of orderIds) {
          await this.updateStatus(id, 'CANCELLED', adminId, { cancelReason: reason });
        }
        return orderIds.length;
      }
      default:
        throw new AppError(`Unknown bulk action: ${action}`, HTTP_STATUS.BAD_REQUEST);
    }
  }

  private async reserveStock(orderId: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true },
    });
    if (!order) return;

    for (const item of order.items) {
      await prisma.inventory.updateMany({
        where: { productId: item.productId },
        data: { reserved: { increment: item.quantity } },
      });
    }
  }

  private async restoreStock(
    orderId: string,
    adminId: string,
    tx?: Prisma.TransactionClient
  ) {
    const client = tx ?? prisma;
    const order = await client.order.findUnique({
      where: { id: orderId },
      include: { items: true },
    });
    if (!order) return;

    for (const item of order.items) {
      await client.inventory.updateMany({
        where: { productId: item.productId },
        data: { reserved: { decrement: item.quantity } },
      });
      await client.stockMovement.create({
        data: {
          inventoryId: '',  // will be looked up
          type:        'UNRESERVE',
          quantity:    item.quantity,
          previousStock: 0,
          newStock:    0,
          reason:      `Order ${order.orderNo} cancelled/returned`,
          reference:   orderId,
          adminId,
        },
      }).catch(() => null); // Non-blocking
    }
  }
}

export const orderService = new OrderService();
