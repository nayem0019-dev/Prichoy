export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE: 422,
  TOO_MANY_REQUESTS: 429,
  INTERNAL_SERVER_ERROR: 500,
} as const;

export const ROLES = {
  SUPER_ADMIN: 'SUPER_ADMIN',
  ADMIN: 'ADMIN',
  ORDER_MANAGER: 'ORDER_MANAGER',
  INVENTORY_MANAGER: 'INVENTORY_MANAGER',
  CUSTOMER_SUPPORT: 'CUSTOMER_SUPPORT',
  DELIVERY_MANAGER: 'DELIVERY_MANAGER',
  ACCOUNTANT: 'ACCOUNTANT',
} as const;

// Roles that can access each module
export const ROLE_PERMISSIONS = {
  orders: {
    view:   ['SUPER_ADMIN','ADMIN','ORDER_MANAGER','CUSTOMER_SUPPORT','DELIVERY_MANAGER','ACCOUNTANT'],
    create: ['SUPER_ADMIN','ADMIN','ORDER_MANAGER'],
    update: ['SUPER_ADMIN','ADMIN','ORDER_MANAGER','DELIVERY_MANAGER'],
    delete: ['SUPER_ADMIN','ADMIN'],
    export: ['SUPER_ADMIN','ADMIN','ORDER_MANAGER','ACCOUNTANT'],
  },
  products: {
    view:   ['SUPER_ADMIN','ADMIN','ORDER_MANAGER','INVENTORY_MANAGER','CUSTOMER_SUPPORT','ACCOUNTANT'],
    create: ['SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'],
    update: ['SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'],
    delete: ['SUPER_ADMIN','ADMIN'],
    export: ['SUPER_ADMIN','ADMIN','INVENTORY_MANAGER','ACCOUNTANT'],
  },
  inventory: {
    view:   ['SUPER_ADMIN','ADMIN','INVENTORY_MANAGER','ORDER_MANAGER'],
    create: ['SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'],
    update: ['SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'],
    delete: ['SUPER_ADMIN','ADMIN'],
    export: ['SUPER_ADMIN','ADMIN','INVENTORY_MANAGER','ACCOUNTANT'],
  },
  customers: {
    view:   ['SUPER_ADMIN','ADMIN','ORDER_MANAGER','CUSTOMER_SUPPORT','ACCOUNTANT'],
    update: ['SUPER_ADMIN','ADMIN','CUSTOMER_SUPPORT'],
    delete: ['SUPER_ADMIN','ADMIN'],
    export: ['SUPER_ADMIN','ADMIN','ACCOUNTANT'],
  },
  reports: {
    view:   ['SUPER_ADMIN','ADMIN','ACCOUNTANT'],
    export: ['SUPER_ADMIN','ADMIN','ACCOUNTANT'],
  },
  settings: {
    view:   ['SUPER_ADMIN','ADMIN'],
    update: ['SUPER_ADMIN'],
  },
  users: {
    view:   ['SUPER_ADMIN','ADMIN'],
    create: ['SUPER_ADMIN'],
    update: ['SUPER_ADMIN'],
    delete: ['SUPER_ADMIN'],
  },
} as const;

export const COURIERS = [
  { name: 'Pathao',     website: 'https://pathao.com' },
  { name: 'SteadFast',  website: 'https://steadfast.com.bd' },
  { name: 'RedX',       website: 'https://redx.com.bd' },
  { name: 'Paperfly',   website: 'https://paperfly.com.bd' },
  { name: 'Sundarban',  website: 'https://www.sundarban.com' },
] as const;

export const DELIVERY_CHARGES = {
  DHAKA_CITY: 80,
  OUTSIDE_DHAKA: 120,
} as const;

export const DHAKA_DISTRICTS = [
  'Dhaka', 'Gazipur', 'Narayanganj', 'Narsingdi',
  'Manikganj', 'Munshiganj', 'Tangail', 'Kishoreganj', 'Faridpur',
];

export const ORDER_STATUS_FLOW: Record<string, string[]> = {
  PENDING:          ['CONFIRMED', 'CANCELLED'],
  CONFIRMED:        ['PACKED',    'CANCELLED'],
  PACKED:           ['DISPATCHED','CANCELLED'],
  DISPATCHED:       ['OUT_FOR_DELIVERY', 'RETURNED'],
  OUT_FOR_DELIVERY: ['DELIVERED', 'RETURNED'],
  DELIVERED:        ['REFUNDED'],
  CANCELLED:        [],
  RETURNED:         ['REFUNDED'],
  REFUNDED:         [],
};

export const PAGINATION = {
  DEFAULT_PAGE:  1,
  DEFAULT_LIMIT: 20,
  MAX_LIMIT:     100,
} as const;
