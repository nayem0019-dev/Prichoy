import { Router } from 'express';
import * as ctrl from '../controllers/order.controller';
import { authenticate, authorize } from '../middlewares/auth.middleware';
import { auditLog } from '../middlewares/audit.middleware';

const router = Router();
router.use(authenticate);

// Dashboard
router.get('/dashboard',      ctrl.getDashboard);
router.get('/recent',         ctrl.getRecentOrders);
router.get('/chart/sales',    ctrl.getSalesChart);

// Orders CRUD
router.get('/',               authorize('SUPER_ADMIN','ADMIN','ORDER_MANAGER','CUSTOMER_SUPPORT','DELIVERY_MANAGER','ACCOUNTANT'),
                              ctrl.getOrders);
router.get('/:id',            ctrl.getOrder);
router.post('/',              authorize('SUPER_ADMIN','ADMIN','ORDER_MANAGER'), ctrl.createOrder);

// Status workflow
router.put('/:id/status',     authorize('SUPER_ADMIN','ADMIN','ORDER_MANAGER','DELIVERY_MANAGER'),
                              auditLog('UPDATE_ORDER_STATUS','orders'),
                              ctrl.updateOrderStatus);

// Notes
router.post('/:id/note',      ctrl.addNote);

// Courier
router.put('/:id/courier',    authorize('SUPER_ADMIN','ADMIN','ORDER_MANAGER','DELIVERY_MANAGER'),
                              ctrl.assignCourier);

// Return / Refund
router.post('/:id/return',    authorize('SUPER_ADMIN','ADMIN','ORDER_MANAGER'), ctrl.processReturn);
router.post('/:id/refund',    authorize('SUPER_ADMIN','ADMIN','ACCOUNTANT'),    ctrl.processRefund);

// Bulk
router.post('/bulk',          authorize('SUPER_ADMIN','ADMIN','ORDER_MANAGER'), ctrl.bulkAction);

export default router;
