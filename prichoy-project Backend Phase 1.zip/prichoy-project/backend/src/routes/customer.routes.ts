import { Router } from 'express';
import * as ctrl from '../controllers/customer.controller';
import { authenticate, authorize } from '../middlewares/auth.middleware';

const router = Router();
router.use(authenticate);

router.get('/stats',      ctrl.getCustomerStats);
router.get('/top',        ctrl.getTopCustomers);
router.get('/',           ctrl.getCustomers);
router.get('/:id',        ctrl.getCustomer);
router.put('/:id',        authorize('SUPER_ADMIN','ADMIN','CUSTOMER_SUPPORT'), ctrl.updateCustomer);
router.post('/:id/note',  ctrl.addNote);
router.post('/:id/block', authorize('SUPER_ADMIN','ADMIN'), ctrl.blockCustomer);
router.post('/:id/unblock', authorize('SUPER_ADMIN','ADMIN'), ctrl.unblockCustomer);

export default router;
