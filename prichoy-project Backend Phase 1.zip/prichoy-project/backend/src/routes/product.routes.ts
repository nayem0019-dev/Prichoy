import { Router } from 'express';
import * as ctrl from '../controllers/product.controller';
import { authenticate, authorize } from '../middlewares/auth.middleware';
import { auditLog } from '../middlewares/audit.middleware';

const router = Router();
router.use(authenticate);

// Categories (no auth on GET for customer site)
router.get('/categories',          ctrl.getCategories);
router.post('/categories',         authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'), ctrl.createCategory);
router.put('/categories/:id',      authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'), ctrl.updateCategory);
router.delete('/categories/:id',   authorize('SUPER_ADMIN','ADMIN'), ctrl.deleteCategory);

// Brands
router.get('/brands',              ctrl.getBrands);
router.post('/brands',             authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'), ctrl.createBrand);
router.put('/brands/:id',          authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'), ctrl.updateBrand);
router.delete('/brands/:id',       authorize('SUPER_ADMIN','ADMIN'), ctrl.deleteBrand);

// Analytics
router.get('/low-stock',           ctrl.getLowStockProducts);
router.get('/top-selling',         ctrl.getTopSellingProducts);

// Products CRUD
router.get('/',                    ctrl.getProducts);
router.get('/:id',                 ctrl.getProduct);
router.post('/',                   authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'),
                                   auditLog('CREATE_PRODUCT','products'), ctrl.createProduct);
router.put('/:id',                 authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'),
                                   auditLog('UPDATE_PRODUCT','products'), ctrl.updateProduct);
router.delete('/:id',              authorize('SUPER_ADMIN','ADMIN'),
                                   auditLog('DELETE_PRODUCT','products'), ctrl.deleteProduct);

// Images
router.post('/:id/images',         authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'), ctrl.addProductImage);
router.delete('/:productId/images/:imageId', authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER'), ctrl.deleteProductImage);

export default router;
