import { Router } from 'express';
import * as ctrl from '../controllers/export.controller';
import { authenticate, authorize } from '../middlewares/auth.middleware';

const router = Router();
router.use(authenticate);

router.get('/orders',                authorize('SUPER_ADMIN','ADMIN','ORDER_MANAGER','ACCOUNTANT'), ctrl.exportOrders);
router.get('/products',              authorize('SUPER_ADMIN','ADMIN','INVENTORY_MANAGER','ACCOUNTANT'), ctrl.exportProducts);
router.get('/customers',             authorize('SUPER_ADMIN','ADMIN','ACCOUNTANT'), ctrl.exportCustomers);
router.get('/invoice/:id',           ctrl.downloadInvoice);

export default router;
