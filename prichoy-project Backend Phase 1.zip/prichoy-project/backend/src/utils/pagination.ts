import { PAGINATION } from '../constants';
import { PaginationMeta, PaginationQuery } from '../types';

export function getPaginationParams(query: PaginationQuery): {
  skip: number;
  take: number;
  page: number;
  limit: number;
} {
  const page  = Math.max(1, Number(query.page)  || PAGINATION.DEFAULT_PAGE);
  const limit = Math.min(
    PAGINATION.MAX_LIMIT,
    Math.max(1, Number(query.limit) || PAGINATION.DEFAULT_LIMIT)
  );
  return { skip: (page - 1) * limit, take: limit, page, limit };
}

export function buildPaginationMeta(
  total: number, page: number, limit: number
): PaginationMeta {
  return {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  };
}
